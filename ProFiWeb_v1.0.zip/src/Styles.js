import { Platform, Dimensions } from "react-native";

const width = Dimensions.get('window').width; //full width
const height = Dimensions.get('window').height; //full width

const colors = {
    darkBlue: '#222f56',
    mediumBlue: '#808aa5',
    lightBlue: '#ced7e4',
    whiteBlue: '#e5eaf0',
    //lightGrey: '#f2f3f4',
    lightGrey: '#d2d3d4',
    darkGrey: '#333333',
    red: '#640023',
    white: 'white'
}

const iconsize = 35;
const iconsizeAdd = 60;

const headerHeight = 100;
const padding = 15;

const boxes = {
    mainContainer: {
        height: "100%",
        width: "100%",
        paddingHorizontal: 20,
        backgroundColor: colors.lightGrey,
        alignItems: "center",
        justifyContent: "center",
    },
    header: {
        height: 100,
        backgroundColor: colors.darkBlue,
    },
    subHeader: {
        backgroundColor: colors.lightBlue,
        paddingVertical: 7,
    },
    paddedRow: {
        width: "100%",
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 15,
    },
    unPaddedRow: {
        width: "100%",
        flexDirection: "row",
        justifyContent: "space-between",
    },
    centeredRow: {
        width: "100%",
        alignItems: "center",
    },
    inputField: {
        minHeight: 45,
        width: "100%",
        paddingHorizontal: 10,
        marginVertical: 5,
        backgroundColor: "white",
        borderBottomWidth: 1,
        borderColor: colors.lightBlue,
        borderRadius: 7,
        fontFamily: 'Inter_400Regular',
        fontSize: 16,
    },
    buttonIcon: {
        width: 35,
        height: 35,
        tintColor: "white"
    },
    buttonIconInactive:{
        height: 45,
        width: 45,
        marginVertical: 5,
        marginHorizontal: 0,
        backgroundColor: colors.lightBlue,
        borderRadius: 7,
        justifyContent: "center",
        alignItems: "center"
    },
    buttonIconActive:{
        height: 45,
        width: 45,
        marginVertical: 5,
        marginHorizontal: 0,
        backgroundColor: colors.darkBlue,
        borderRadius: 7,
        justifyContent: "center",
        alignItems: "center"
    },
    buttonIconNeg: {
        height: 45,
        width: 45,
        marginVertical: 5,
        marginHorizontal: 0,
        backgroundColor: colors.red,
        borderRadius: 7,
        justifyContent: "center",
        alignItems: "center"
    },
    buttonSmall: {
        height: 45,
        width: ('100%' - 40) / 2,
        paddingLeft: 15,
        paddingRight: 5,
        marginVertical: 5,
        backgroundColor: colors.darkBlue,
        borderRadius: 7,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center"
    },
    buttonSmallInactive: {
        height: 45,
        width: (width - 40) / 2,
        paddingLeft: 15,
        paddingRight: 5,
        marginVertical: 5,
        backgroundColor: colors.lightBlue,
        borderRadius: 7,
        borderWidth: 2,
        borderColor: colors.white,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center"
    },
    buttonLargeSolid: {
        height: 45,
        width: "100%",
        paddingHorizontal: 10,
        marginVertical: 5,
        backgroundColor: colors.darkBlue,
        borderRadius: 7,
        justifyContent: "center",
    },
    buttonLargeTransparent: {
        height: 40,
        width: "100%",
        paddingHorizontal: 10,
        marginVertical: 5,
        backgroundColor: "none",
        borderRadius: 0,
        justifyContent: "center",
    },
    listTile: {
        paddingLeft: 15,
        paddingRight: 35,
        height: 90,
        //width: "100%",
        alignItems: "left",
        justifyContent: "center",
    },
    listTileHeader: {
        flexDirection: "row",
        justifyContent: "left",
    },
    listTileArrow: {
        position: "absolute",
        right: 15,
        width: 15,
        tintColor: colors.lightBlue,
        zIndex: -1
    },
    listTileIcon: {
        width: 22, 
        height: 22, 
        tintColor: colors.darkBlue, 
        marginEnd: 5,  
        marginTop: 0.5  
    },
    scrollRow: {
        height: 100,
        width: "100%",
        paddingVertical: 10,
    },

    profileImage: {
            width: 60,
            height: 60,
            borderRadius: 111,
            aspectRatio: 1,
            marginRight: 7,
            //tintColor: colors.white
        // height: "100%",
        // marginRight: 7,
        // aspectRatio: 1,
        // backgroundColor: colors.lightBlue,
        // borderRadius: 111
    },
    profileViewImage: {
        width: width,
        height: 150,
        alignItems: "center",
        borderRadius: 111
    },
    attributeImage: {
        width: 60,
        height: 60,
        // height: "100%",
        aspectRatio: 1,
        marginRight: 7,
        flex: 1,
        backgroundColor: colors.lightGrey,
        borderRadius: 7,
        justifyContent: 'center',
        alignItems: 'center',
    },
    attributeIcon: {
        width: "75%",
        height: "75%",
        tintColor: colors.mediumBlue,
    },
    attributeTile: {
        paddingLeft: 15,
        paddingRight: 35,
        height: 45,
        width: "100%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-start",
    },
    attributeCheckmark: {
        height: 25,
        width: 25,
        marginRight: 10,
        tintColor: colors.darkBlue
    },
}

const buttons = {
    
    buttonRow: {
        width: width/7*3,
        height: 45,
        paddingLeft: 15,
        paddingRight: 10,
        backgroundColor: colors.darkBlue,
        borderRadius:10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },

    buttonRowGrey: {
        width: width/7*3,
        height: 45,
        paddingLeft: 15,
        paddingRight: 10,
        backgroundColor: colors.lightGrey,
        borderRadius:10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },

    buttonColumn: {
        width: "50%",
        height: 45,
        marginVertical: 10,
        backgroundColor: colors.darkBlue,
        borderRadius:10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },

    buttonSimple: {
        width: "50%",
        height: 45,
        marginVertical: 10,
        backgroundColor: colors.darkBlue,
        borderRadius:10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },

    buttonEvaluate: {
        height: 45,
        marginTop: 10,
        marginHorizontal: 15,
        backgroundColor: colors.darkBlue,
        borderRadius:10,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
}

const texts = {
    
    header: {
        fontFamily: 'Inter_600SemiBold',
        fontSize: 20,
        color: colors.white,
        textAlign: "center"
    },
    titleCentered: {
        fontFamily: 'Inter_400Regular',
        textAlign: "center",
        fontSize: 20,
        paddingBottom: 20
    },
    subHeader: {
        fontFamily: 'Inter_600SemiBold',
        color: colors.darkGrey,
        fontSize: 16,
    },
    buttonSmall: {
        fontFamily: 'Inter_500Medium',
        fontSize: 16,
        color: "white",
        textAlign: "left"
    },
    buttonLargeSolid: {
        fontFamily: 'Inter_500Medium',
        fontSize: 16,
        color: "white",
        textAlign: "center"
    },
    buttonLargeTransparent: {
        fontFamily: 'Inter_400Regular',
        fontSize: 16,
        color: colors.darkBlue,
        textAlign: "center",
    },

    listTileHeader: {
        fontSize: 20,
        color: colors.darkBlue,
        fontFamily: 'Inter_700Bold',
        marginBottom: 5,
    },
    commentTileHeader: {
        fontSize: 18,
        color: colors.darkBlue,
        fontFamily: 'Inter_600SemiBold',
        marginBottom: 5,
    },
    
    headerWithBackIcon: {
        fontSize: 24,
        letterSpacing: 0.5,
        fontFamily: 'Inter_700Bold',
        color: colors.white,
        marginLeft: (Platform.OS === 'android') ? -15 : 0,
        alignSelf: (Platform.OS === 'android') ? 'flex-start' : 'center'
    },

    headline: {
        fontSize: 22,
        fontFamily: 'Inter_700Bold',
        color: colors.darkBlue,
    },

    text: {
        fontFamily: 'Inter_400Regular',
        fontSize: 16,
        color: colors.darkGrey
    },

    textProfile: {
        fontFamily: 'Inter_400Regular',
        fontSize: 18,
        color: colors.darkGrey,
        marginTop: 15
    },

    textBoldAttribute: {
        fontFamily: 'Inter_700Bold',
        fontSize: 24,
        color: colors.darkBlue,    
        paddingVertical: 7,
        paddingHorizontal: "5%"
    },

    textAttribute: {
        fontFamily: 'Inter_400Regular',
        fontSize: 18,
        color: colors.darkGrey,
        lineHeight: 25,
        textAlign: "justify",
        paddingVertical: 7,
        paddingHorizontal: "5%"
    },
    
    textBold: {
        fontSize: 18,
        color: colors.darkGrey,
        fontFamily: 'Inter_700Bold',
    },

    headlineCenter: {
        fontSize: 18,
        fontFamily: 'Inter_700Bold',
        color: colors.darkGrey,
        textAlign: 'center'
    },

    inputText: {
        fontFamily: 'Inter_400Regular',
        fontSize: 18,
        color: colors.darkGrey,
        backgroundColor: colors.white,
        width: "100%",
        paddingVertical: 5,
        paddingLeft: 5,
        marginTop: 3,
        borderRadius: 3,
    },

    inputTextProfile: {
        fontSize: 24,
        color: colors.darkGrey,
        fontFamily: 'Inter_700Bold',
    },
    
    inputField: {
        fontFamily: 'Inter_400Regular',
        fontSize: 16,
    },

    buttonBlue: {
        fontSize: 17, 
        fontFamily: 'Inter_700Bold',
        color: colors.white,
        maxWidth: "85%"
    },
    
    buttonBlueCenter: {
        fontSize: 17, 
        fontFamily: 'Inter_700Bold',
        color: colors.white,
        textAlign: "center",
        width: "100%"
    },

    buttonGrey: {
        fontSize: 17, 
        fontFamily: 'Inter_700Bold',
        color: colors.darkGrey,
    },
}

const profileImage = {
      
    cameraPreview: {
        width: 100,
        height: 100,
        borderRadius: 100,
    },

    imageTile: {
        shadowColor: "black",
        shadowOpacity: 0.2,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 10,
        borderRadius: 10,
        padding: 15,
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 30,
    }
}

const icons = {
    profilePlaceholder: require("./assets/ui-icons/user.png"),
    checkTrue: require("./assets/icons/check-true.png"),
    checkFalse: require("./assets/icons/check-false.png"),
    home: require("./assets/ui-icons/home.png"),
    profile: require("./assets/ui-icons/profile.png"),
    plus: require("./assets/ui-icons/plus.png"),
    minus: require("./assets/ui-icons/minus.png"),
    find: require("./assets/ui-icons/find.png"),
    exit: require("./assets/ui-icons/exit.png"),
    fav: require("./assets/ui-icons/favourite.png"),
    nogo: require("./assets/ui-icons/nogo.png"),
    delete: require("./assets/ui-icons/delete.png"),
    like: require("./assets/ui-icons/like.png"),
    reply: require("./assets/ui-icons/reply.png"),
}

export { boxes, buttons, texts, colors, iconsize, iconsizeAdd, icons, profileImage, width, height }