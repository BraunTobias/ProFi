import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import CourseScreen from '../screens/CourseScreen';
import IdeaScreen from '../screens/IdeaScreen';
import { boxes, texts, colors } from '../Styles';

const MainStack = createStackNavigator();

export default function AuthenticationNavigator () {
    return (
        <NavigationContainer>
            <MainStack.Navigator 
                initialRouteName="Login" 
                screenOptions={{
                    headerStyle: boxes.header,
                    headerTitleStyle: texts.header,
                    headerTintColor: colors.white,
                    
            }}>
                <MainStack.Screen 
                    name = "Home" 
                    component= {HomeScreen} 
                    options={{
                        headerTitle: 'Meine Kurse', 
                    }}
                />
                <MainStack.Screen 
                    name = "Course" 
                    component = {CourseScreen} 
                    options={{
                        headerBackTitleVisible: false, 
                        headerLeftContainerStyle: {
                            marginHorizontal: 10
                        }
                    }}
                />
                <MainStack.Screen 
                    name = "Idea" 
                    component = {IdeaScreen} 
                    options={{
                        headerBackTitleVisible: false, 
                        headerLeftContainerStyle: {
                            marginHorizontal: 10
                        }
                    }}
                />
                <MainStack.Screen 
                    name = "IdeaAttributes" 
                    component = {HomeScreen} 
                    options={{
                        headerBackTitleVisible: false, 
                        headerLeftContainerStyle: {
                            marginHorizontal: 10
                        }
                    }}
                />
                <MainStack.Screen 
                    name = "Mein Profil" 
                    component = {HomeScreen} 
                    options={{
                        headerBackTitleVisible: false, 
                        headerLeftContainerStyle: {
                            marginHorizontal: 10
                        }
                    }}
                />
            </MainStack.Navigator>
        </NavigationContainer>
    );
};