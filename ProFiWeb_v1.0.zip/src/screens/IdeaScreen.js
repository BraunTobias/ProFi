import React, {useState, useEffect, useLayoutEffect} from 'react';
import { View, Text, Modal, FlatList, TouchableHighlight, Keyboard, ActivityIndicator, Alert } from 'react-native';
// import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';
import { compareAsc, format } from 'date-fns';

import { icons, colors, boxes, texts } from '../Styles';
import DB from '../api/DB_API';
import InputField from '../components/InputField';
// import SwipeButton from '../components/SwipeButton';
import CommentTile from '../components/CommentTile';
import ModalContent from "../components/ModalContent";
import ButtonLarge from '../components/ButtonLarge';
import ButtonIcon from '../components/ButtonIcon';
import ScrollRow from '../components/ScrollRow';
import AttributePreviewTile from '../components/AttributePreviewTile';
import ProfileView from '../components/ProfileView';
import AttributeSelect from '../components/AttributeSelect';
import Padding from '../components/Padding';

export default function IdeaScreen ({route, navigation}) {

    const {itemId} = route.params;
    const {itemTitle} = route.params;
    const {itemDescription} = route.params;
    const {courseId} = route.params;
    const currentUserId = DB.getCurrentUserId();

    // State Hooks
    const [currentSkills, setCurrentSkills] = useState([]);
    const [currentComments, setCurrentComments] = useState([]);
    const [swipeListView, setSwipeListView] = useState();
    const [currentUserIsCreator, setCurrentUserIsCreator] = useState(false);
    const [ideaText, setIdeaText] = useState(itemDescription);
    const [ideaName, setIdeaName] = useState(itemTitle);
    const [ideaCreator, setIdeaCreator] = useState("");
    const [commentsLoading, setCommentsLoading] = useState(true);

    // State Hooks für Modal
    const [editIdeaVisible, setEditIdeaVisible] = useState(false);
    const [addSkillsVisible, setAddSkillsVisible] = useState(false);
    const [editIdeaName, setEditIdeaName] = useState(itemTitle);
    const [editIdeaText, setEditIdeaText] = useState(itemDescription);
    const [selectedSkillsList, setSelectedSkillsList] = useState([]);
    const [newCommentVisible, setNewCommentVisible] = useState(false);
    const [newReplyVisible, setNewReplyVisible] = useState(false);
    const [currentNewCommentText, setCurrentNewCommentText] = useState("");
    const [currentReplyText, setCurrentReplyText] = useState("");
    const [currentReplyComment, setCurrentReplyComment] = useState({});
    const [currentCommentErrorVisible, setCurrentCommentErrorVisible] = useState(false);
    const [editIdeaNameErrorVisible, setEditIdeaNameErrorVisible] = useState(false);
    const [editIdeaTextErrorVisible, setEditIdeaTextErrorVisible] = useState(false);
    const [selectedSkillsListErrorVisible, setSelectedSkillsListErrorVisible] = useState(false);

    // State Hooks für Profilansicht
    const [viewedUserId, setViewedUserId] = useState(currentUserId);
    const [profileVisible, setProfileVisible] = useState(false);

    useLayoutEffect(() => {
        navigation.setOptions({
            headerTitle: courseId,
        });
    }, [navigation]);

    useEffect(() => {
        DB.getCommentsList(courseId, itemId, (commentsList) => {
            // console.log('commentsList: ');
            // console.log(commentsList);
            setCurrentComments(commentsList);
            setCommentsLoading(false);
        });
        DB.getIdeaData(courseId, itemId, (data) => {
            setCurrentSkills(data.skills);
            setSelectedSkillsList(data.skills);
            DB.getUserInfoById(data.creator, (userName) => {
                setIdeaCreator(userName);
            });
            if (data.creator == currentUserId) setCurrentUserIsCreator(true);
            if (data.team && data.team.length > 0) {
                const teamUidList = data.team;
                var newTeamList = [];
                for (const member in teamUidList) {
                    const uid = teamUidList[member];
                    DB.getUserInfoById(uid, (name, url) => {
                        newTeamList.push({
                            "userId": uid,
                            "username": name,
                            "imageUrl": url
                        });
                        // setTeam(newTeamList);
                    });
                }
            }
        });
    }, []);

    const likeCommentHandler = (commentId) => {
        DB.likeComment(courseId, itemId, commentId, () => {
            DB.getCommentsList(courseId, itemId, (commentsList) => {
                setCurrentComments(commentsList);
                // swipeListView.safeCloseOpenRow();
            });
        });
    }
    const deleteCommentHandler = (commentId) => {
        DB.deleteComment(courseId, itemId, commentId);
        DB.getCommentsList(courseId, itemId, (commentsList) => {
            setCurrentComments(commentsList);
            // swipeListView.safeCloseOpenRow();
        });
    }

    const viewProfileHandler = (id) => {
        setViewedUserId(id);
        setProfileVisible(true);
    }

    // Handler für Modal
    const changeNewCommentTextHandler = (enteredText) => {
        setCurrentNewCommentText(enteredText);
        if (enteredText != "") setCurrentCommentErrorVisible(false);
    }
    const changeReplyTextHandler = (enteredText) => {
        setCurrentReplyText(enteredText);
        if (enteredText != "") setCurrentCommentErrorVisible(false);
    }
    const pressNewCommentHandler = (committed) => {
        if (committed) {
            if (currentNewCommentText != "") {
                DB.addComment(courseId, itemId, currentNewCommentText, "", () => {
                    setNewCommentVisible(false);
                    setCurrentNewCommentText("");
                    DB.getCommentsList(courseId, itemId, (commentsList) => {
                        setCurrentComments(commentsList);
                    });
                });
            } else {
                setCurrentCommentErrorVisible(true);
            }
        } else {
            setNewCommentVisible(false);
            setCurrentCommentErrorVisible(false);
        }
    }
    const pressReplyHandler = (committed) => {
        if (committed) {
            if (currentReplyText != "") {
                DB.addComment(courseId, itemId, currentReplyText, currentReplyComment.id, () => {
                    setNewReplyVisible(false);
                    setCurrentNewCommentText("");
                    DB.getCommentsList(courseId, itemId, (commentsList) => {
                        setCurrentComments(commentsList);
                    });
                });
            } else {
                setCurrentCommentErrorVisible(true);
            }
        } else {
            setNewReplyVisible(false);
            setCurrentCommentErrorVisible(false);
        }
        // swipeListView.safeCloseOpenRow();
    }

    const changeEditIdeaNameHandler = (enteredText) => {
        setEditIdeaName(enteredText);
        if (editIdeaName.length > 1) setEditIdeaNameErrorVisible(false);
    }
    const changeEditIdeaTextHandler = (enteredText) => {
        setEditIdeaText(enteredText);
        if (editIdeaText.length > 1) setEditIdeaTextErrorVisible(false);
    }
    const addSkillHandler = (skill) => {
        var oldList = selectedSkillsList;
        if (oldList.indexOf(skill) < 0) {
            oldList.push(skill);
        } else {
            var newList = oldList.filter(item => item !== skill);
            setSelectedSkillsList(newList);
        }
        if (selectedSkillsList.length > 0) setSelectedSkillsListErrorVisible(false);
    }
    const pressEditIdeaHandler = (committed) => {
        if (committed) {
            if (editIdeaName.length > 1 && editIdeaText.length > 1 && selectedSkillsList.length > 0) {
                DB.editIdea(courseId, itemId, editIdeaName, editIdeaText, selectedSkillsList, [], () => {
                    setEditIdeaVisible(false);
                    setEditIdeaTextErrorVisible(false);
                    setEditIdeaNameErrorVisible(false);
                    setSelectedSkillsListErrorVisible(false);
                    setCurrentSkills(selectedSkillsList);
                    setSelectedSkillsList(selectedSkillsList);
                    setIdeaName(editIdeaName);
                    setIdeaText(editIdeaText);
                }, () => {
                    Alert.alert(
                        "Fehler",
                        "Idee konnte nicht bearbeitet werden",
                        [{ text: "OK", onPress: () => {}}],
                    );              
                });
            }
            if (editIdeaName.length <= 1) setEditIdeaNameErrorVisible(true);
            if (editIdeaText.length <= 1) setEditIdeaTextErrorVisible(true);
            if (selectedSkillsList.length == 0) setSelectedSkillsListErrorVisible(true);
        } else {
            setEditIdeaVisible(false);
            setEditIdeaName(ideaName);
            setEditIdeaText(ideaText);
            setSelectedSkillsList(currentSkills);
            setEditIdeaNameErrorVisible(false);
            setEditIdeaTextErrorVisible(false);
            setSelectedSkillsListErrorVisible(false);
        }
    }

    const swipeButtons = (item) => {
        if (item.replyTo) {
            // Comment-autor: delete-button
            return(
                <View style={[boxes.swipeRowOne, {backgroundColor: colors.red}]}>
                    <ButtonIcon 
                        icon= { item.user == currentUserId ? 'delete' : 'like' }
                        onPress= { (ref) => { item.user == currentUserId ? deleteCommentHandler(item.id) : likeCommentHandler(item.id) } }
                        status= { "active" }
                    />
                    {/* <SwipeButton
                        icon={item.user == currentUserId ? icons.delete : icons.like}
                        backgroundColor={item.user == currentUserId ? colors.red : item.likes.indexOf(currentUserId) < 0 ? colors.darkBlue : colors.lightBlue}
                        onPress={() => {item.user == currentUserId ? deleteCommentHandler(item.id) : likeCommentHandler(item.id)}}
                    /> */}
                </View>
            );
        } 
        // Comment-reader: Fav- & Reply-button
        else {
            return(
                <View style={[boxes.unPaddedRow, {backgroundColor: colors.mediumBlue}]}>
                    <ButtonIcon 
                        icon= { item.user == currentUserId ? 'del' : 'like' }
                        onPress= { (ref) => { item.user == currentUserId ? deleteCommentHandler(item.id) : likeCommentHandler(item.id) } }
                        status= { "active" }
                    />
                    <ButtonIcon 
                        icon= { 'reply' }
                        onPress= { (ref) => { setNewReplyVisible(true); setCurrentReplyComment(item) } }
                        status= { "active" }
                    />
                    {/* <SwipeButton
                        icon={item.user == currentUserId ? icons.delete : icons.like}
                        backgroundColor={item.user == currentUserId ? colors.red : item.likes.indexOf(currentUserId) < 0 ? colors.darkBlue : colors.lightBlue}
                        onPress={() => {item.user == currentUserId ? deleteCommentHandler(item.id) : likeCommentHandler(item.id)}}
                    />
                    <SwipeButton
                        icon= { 'reply' }
                        backgroundColor={colors.mediumBlue}
                        onPress={() => {setNewReplyVisible(true); setCurrentReplyComment(item)}}
                    /> */}
                </View>
            );
        }
    }

    return(
        <View style={{flex:1}}>

            { profileVisible &&
                <ProfileView
                    userId={viewedUserId}
                    visible={profileVisible}
                    onDismiss={() => {setProfileVisible(false)}}
                />
            }

            {/* Kommentar schreiben */}
            <Modal visible= { newCommentVisible } animationType= 'slide'>
                <ModalContent
                    subheader= { () => {}}
                    content= { () => {
                        return(
                            <View style={boxes.mainContainer}>
                                <Text style={texts.titleCentered}>{"Kommentar schreiben"}</Text>
                                <InputField
                                    placeholderText= "max. 300 Zeichen"
                                    value={currentNewCommentText}
                                    onChangeText={changeNewCommentTextHandler}
                                    multiline={true}
                                />
                                {currentCommentErrorVisible &&
                                    <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                        Bitte einen Kommentar eingeben.
                                    </Text>
                                }
                            </View> 
                        )
                    }}
                    onDismiss= {(committed) => {pressNewCommentHandler(committed)}}
                />
            </Modal>
            
            {/* Auf Kommentar antworten */}
            <Modal visible= { newReplyVisible } animationType= 'slide'>
                <ModalContent
                    subheader= { () => {}}
                    content= { () => {
                        return(
                            <View style={boxes.mainContainer}>
                                <Text style={texts.titleCentered}>{"Antwort schreiben"}</Text>
                                <View style={{marginLeft: 20}}>
                                    <CommentTile
                                        userId={currentReplyComment.user}
                                        userName={currentReplyComment.name}
                                        userUrl={currentReplyComment.url}
                                        comment={currentReplyComment.text}
                                        timestamp={currentReplyComment.time}
                                        likes={currentReplyComment.likes.length}
                                    />
                                </View>
                                <InputField
                                    placeholderText= "max. 300 Zeichen"
                                    value={currentReplyText}
                                    onChangeText={changeReplyTextHandler}
                                    multiline={true}
                                />
                                {currentCommentErrorVisible &&
                                    <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                        Bitte eine Antwort eingeben.
                                    </Text>
                                }
                            </View> 
                        )
                    }}
                    onDismiss= {pressReplyHandler}
                />
            </Modal>
                
            {/* Idee bearbeiten */}
            <Modal visible= { editIdeaVisible } animationType= 'slide'>
                <ModalContent
                    subheader= { () => {}}
                    content= { () => {
                        return(
                            <View style={boxes.mainContainer}>
                                <Text style={texts.titleCentered}>{"Idee bearbeiten"}</Text>
                                <InputField
                                    placeholderText= "Titel"
                                    value={editIdeaName}
                                    onChangeText={changeEditIdeaNameHandler}
                                />
                                {editIdeaNameErrorVisible &&
                                    <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                        Bitte einen Namen angeben.
                                    </Text>
                                }
                                <InputField
                                    placeholderText= "Beschreibung"
                                    value={editIdeaText}
                                    onChangeText={changeEditIdeaTextHandler}
                                    multiline={true}
                                />
                                {editIdeaTextErrorVisible &&
                                    <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                        Bitte einen Beschreibungstext angeben.
                                    </Text>
                                }
                                {/* Fähigkeiten auswählen */}
                                <AttributeSelect
                                    attributeType = "skills"
                                    selectedAttributesList={selectedSkillsList}
                                    addAttribute = { (skills) => { addSkillHandler(skills) } }
                                    // onDismiss = {() => {setAddSkillsVisible(false)}}
                                />
                                <AttributePreviewTile
                                    title="Passende Fähigkeiten"
                                    subtitle={selectedSkillsList.join(", ")}
                                    index={0}
                                    onPress={() => {setAddSkillsVisible(true)}}
                                />
                                {selectedSkillsListErrorVisible &&
                                    <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                        Bitte mindestens eine Fähigkeit angeben.
                                    </Text>
                                }
                            </View> 
                        )
                    }}
                    onDismiss= {pressEditIdeaHandler}
                />
            </Modal>

            {/* Header */}
            <View style={ boxes.subHeader }>
                <Text style={texts.ideaFooter}>{"Idee von " + ideaCreator}</Text>
                <View style={ boxes.paddedRow }>
                    <Text style={texts.subHeaderLarge}>{ideaName}</Text>
                </View>
                <View style={ boxes.paddedRow }>
                    <Text style={texts.copy}>{ideaText}</Text>
                </View>
                <View style={ boxes.paddedRow }>
                    <AttributePreviewTile
                        title="Passende Fähigkeiten"
                        subtitle={currentSkills.join(", ")}
                        index={0}
                        onPress={() => navigation.navigate('IdeaAttributes', {attributeType: "skills", filter: currentSkills, title: "Passende Fähigkeiten"})}
                        />
                </View>
            </View>

            {commentsLoading && 
                <View style={{backgroundColor: "white", paddingVertical: 30}}>
                    <ActivityIndicator/>
                </View>
            }
            { currentUserIsCreator &&
                <View style={ boxes.paddedRow }>
                    <ButtonLarge
                        title="Idee bearbeiten"
                        onPress={() => setEditIdeaVisible(true)}
                    />
                </View>
            }
            <FlatList 
                data= { currentComments }
                keyExtractor= { (item, index) => index.toString() }
                renderItem= { (itemData) => { 
                    return (
                        <TouchableHighlight
                            underlayColor={colors.darkBlue}
                        >
                            <View>
                                
                                <CommentTile
                                    id={itemData.item.id}
                                    userId={itemData.item.user}
                                    userName={itemData.item.name}
                                    userUrl={itemData.item.url}
                                    comment={itemData.item.text}
                                    timestamp={itemData.item.time}
                                    likes={itemData.item.likes.length}
                                    isReply={itemData.item.replyTo && itemData.item.replyTo.length > 0}
                                    index = {itemData.index}
                                    onPress = {() => {viewProfileHandler(itemData.item.user)}}
                                />
                                {swipeButtons(itemData.item)}
                            </View>
                        </TouchableHighlight>
                    )
                }}
            />

            <View style={[boxes.paddedRow, {backgroundColor: colors.white, paddingVertical: 5}]}>
                <ButtonLarge
                    title="Kommentar schreiben"
                    onPress={() => {setNewCommentVisible(true)}}
                />
            </View>

        </View>
    )
}