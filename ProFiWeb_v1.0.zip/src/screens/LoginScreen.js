import React, { useState } from 'react';
import { View, Text, Modal, ScrollView } from 'react-native';
//import { ScrollView } from 'react-native-gesture-handler';
import DB from '../api/DB_API';
import ButtonLarge from '../components/ButtonLarge';
import InputField from '../components/InputField';
import { texts, boxes } from '../Styles';

//export default function LoginScreen ({navigation}) {
export default function LoginScreen () {
    
    // State Hooks
    const [currentMail, setCurrentMail] = useState("");
    const [currentPW, setCurrentPW] = useState("");
    const [currentName, setCurrentName] = useState("");

    // State Hooks für Modals
    const [registerVisible, setRegisterVisible] = useState(false);

    // Benutzereingaben-Handling
    const changeMailHandler = (enteredText) => {
        setCurrentMail(enteredText);
    };
    const changePWHandler = (enteredText) => {
        setCurrentPW(enteredText);
    };
    const changeNameHandler = (enteredText) => {
        setCurrentName(enteredText);
    };
    const setRegisterHandler = (visible) => {
        setRegisterVisible(visible);
        setCurrentMail("");
        setCurrentPW("");
        setCurrentName("");
    };
    
    // Login
    const logIn = () => {
        //console.log(currentMail + " " + currentPW)
        //DB.logIn(currentMail, currentPW, (error) => { setErrorVisibility(true) });
        DB.logIn("TobiasBraun@haw-hamburg.de", "123456", ((error) => {console.log(error)}));
        console.log("TobiasBraun@haw-hamburg.de 123456")
    }

    return(
        <View>
            {/* Registrierung */}
            <Modal visible= { registerVisible } animationType= 'slide'>
                <ScrollView contentContainerStyle= { boxes.mainContainer } >
                    <Text style= { texts.titleCentered } >Registrierung</Text>
                    <InputField 
                        title= "Username"
                        placeholderText= "Username"
                        value= { currentName }
                        onChangeText= { changeNameHandler }
                    />
                    <InputField 
                        title= "E-Mail-Adresse"
                        placeholderText= "user@haw-hamburg.de"
                        value= { currentMail }
                        onChangeText= { changeMailHandler }
                    />
                    <InputField 
                        title= "Passwort"
                        secureTextEntry= { true }
                        placeholderText= "mind. 6 Zeichen"
                        value= { currentPW }
                        onChangeText= { changePWHandler }
                    />
                    <ButtonLarge 
                        title= "Konto anlegen" 
                        onPress= { logIn } 
                    />
                    <ButtonLarge 
                        title= "Schon ein Konto? Anmelden" 
                        onPress= { () => { setRegisterHandler(false) } }
                        transparent= { true } 
                    />
                </ScrollView>
            </Modal>

            {/* Login */}
            <View style= { boxes.mainContainer } >
                <Text style= { texts.titleCentered } >Login</Text>
                <InputField
                    title= "E-Mail"
                    placeholderText= "benutzer@haw-hamburg.de"
                    value= { currentMail }
                    onChangeText= { changeMailHandler }
                />
                <InputField 
                    title= "Passwort"
                    secureTextEntry= { true }
                    placeholderText= "mind. 6 Zeichen"
                    value= { currentPW }
                    onChangeText= { changePWHandler }
                />
                <ButtonLarge 
                    title= "Einloggen"
                    onPress= { logIn }
                />
                <ButtonLarge 
                    title= "Noch kein Konto? Registrieren" 
                    transparent= { true }
                    onPress= { () => {setRegisterHandler(true) } }
                />                    
            </View>
        </View>
    );
}