import React, { useState, useEffect } from 'react';
import { View, Text, Modal, FlatList, Alert } from 'react-native';
import { TouchableHighlight, TouchableOpacity, Touchable, ScrollView } from 'react-native-web'
import DB from '../api/DB_API';
//import { SwipeListView } from 'react-native-swipe-list-view';
import { compareAsc, format } from 'date-fns';
import AsyncStorage from '@react-native-community/async-storage';
// import DateTimePickerModal from 'react-native-modal-datetime-picker';

import InputField from '../components/InputField';
import NumberInput from '../components/NumberInput';
import ButtonLarge from '../components/ButtonLarge';
import ButtonSmall from '../components/ButtonSmall';
import ButtonIcon from '../components/ButtonIcon';
//import SwipeButton from '../components/SwipeButton';
import ListTile from "../components/ListTile";
import InfoModal from "../components/InfoModal";
import ModalContent from "../components/ModalContent";
import DateModal from '../components/DateModal'
import { icons, colors, boxes, texts, width, height } from '../Styles';


//export default function LoginScreen ({navigation}) {
export default function HomeScreen ({navigation}) {
    
    const currentUserId = DB.getCurrentUserId();

    // State Hooks
    const [currentWarning, setCurrentWarning] = useState("");
    const [currentCourses, setCurrentCourses] = useState({});
    const [joinedCourses, setJoinedCourses] = useState([]);
    //const [swipeListView, setSwipeListView] = useState();

    // State Hooks für Modals
    const [findCourseVisible, setFindCourseVisible] = useState(false);
    const [currentFindCourseId, setCurrentFindCourseId] = useState("");
    const [newCourseVisible, setNewCourseVisible] = useState(false);
    const [newCourseDateVisible, setNewCourseDateVisible] = useState(false);
    const [currentNewCourseName, setCurrentNewCourseName] = useState("");
    const [newCourseNameError, setNewCourseNameError] = useState(false);
    const [currentNewCourseAcronym, setCurrentNewCourseAcronym] = useState("");
    const [newCourseAcronymError, setNewCourseAcronymError] = useState(false);
    const [currentNewCourseId, setCurrentNewCourseId] = useState("");
    const [currentNewCourseDate, setCurrentNewCourseDate] = useState( new Date( new Date().getTime() + 24 * 60 *60 *1000 ) );
    // const [newCourseDateErrorVisible, setNewCourseDateErrorVisible] = useState(false);
    const [currentNewCourseMinMembers, setCurrentNewCourseMinMembers] = useState(2);
    const [currentNewCourseMaxMembers, setCurrentNewCourseMaxMembers] = useState(2);
    const [deleteInfoVisible, setDeleteInfoVisible] = useState(false);
    const [deleteInfoReceived, setDeleteInfoReceived] = useState(false);
    
    // Für Info-Modal
    const storeInfoReceived = async (info) => {
        try {
          await AsyncStorage.setItem(info, currentUserId);
        } catch(e) {console.log(e);}
    }
    const getInfoReceived = async () => {
        try {
          const deleteInfo = await AsyncStorage.getItem("deleteInfoReceived");
          if (deleteInfo == currentUserId) setDeleteInfoReceived(true);
        } catch(e) {console.log(e);}
    }
      
    const loadData = () => {
        DB.getCourseList((courseList) => {
            setCurrentCourses(courseList);
            var joined = [];
            // console.log('courseList: ')
            // console.log(courseList)
            for (let semester of Object.keys(courseList)) {
                // console.log('semester: ' + semester)
                for (let course in courseList[semester]) {
                    // console.log('course: ' + course)
                    // console.log(courseList[semester][course])                    
                    if (courseList[semester][course].members.indexOf(currentUserId) >= 0) {
                        joined.push(courseList[semester][course].id);
                    }
                }
            }
            // console.log('joined: ')
            // console.log(joined)
            setJoinedCourses(joined);
            getInfoReceived();
        });
    }

    // Wird nach dem Rendern ausgeführt
    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
            loadData();
            // DB.getCourseList((courseList) => {
            //     setCurrentCourses(courseList);
            //     var joined = [];
            //     for (const course in courseList) {
            //         if (courseList[course].members) {
            //             if (courseList[course].members.indexOf(currentUserId) >= 0) {
            //                 joined.push(courseList[course].id);
            //             }
            //         }
            //     }
            //     setJoinedCourses(joined);
            //     getInfoReceived();
            // });
        });
    }, []);

    // Handler für Modals
    const pressFindCourseHandler = (commit) => {
        if (commit && currentFindCourseId != "") {
            DB.addCourseToList(currentFindCourseId, (addedCourse) => {
                setCurrentFindCourseId("");
                var courseList = currentCourses;
                courseList.push(addedCourse);
                setCurrentCourses(courseList);
                setFindCourseVisible(false);
            }, (error) => {
                console.log(error);
            })
        } else {
            setFindCourseVisible(false);
        }
    }
    const changeFindCourseIdHandler = (enteredText) => {
        setCurrentFindCourseId(enteredText.toUpperCase());
    }
    const pressNewCourseHandler = (commit) => {
        if (commit) {            
            if (currentNewCourseDate - (new Date()) >= 0 && currentNewCourseName != "" && currentNewCourseAcronym != "") {
                DB.addCourse(currentNewCourseName, currentNewCourseId, currentNewCourseDate, currentNewCourseMinMembers, currentNewCourseMaxMembers, () => {
                    setNewCourseVisible(false);
                    setCurrentNewCourseName("");
                    setCurrentNewCourseAcronym("");
                    setCurrentNewCourseId("");    
                    setCurrentNewCourseMinMembers("");
                    setCurrentNewCourseMaxMembers("");
                    setCurrentNewCourseDate(new Date());
                    DB.getCourseList((courseList) => {
                        setCurrentCourses(courseList);
                    });
                }, (error) => { console.error(error) } );
            } else {
                // if (currentNewCourseDate - (new Date()) < 0) setNewCourseDateErrorVisible(true);
                if (currentNewCourseName === "") setNewCourseNameError(true);
                if (currentNewCourseAcronym === "")setNewCourseAcronymError(true);
            }
        } else setNewCourseVisible(false);
    }
    const changeNewCourseNameHandler = (enteredText) => {
        setCurrentNewCourseName(enteredText);
        if (currentNewCourseName === "") setNewCourseNameError(true);
        else setNewCourseNameError(false);
    }
    const changeNewCourseAcronymHandler = (enteredText) => {
        setCurrentNewCourseAcronym(enteredText.toUpperCase());
        if (enteredText === "") {
            setNewCourseAcronymError(true);
        } else  {
            setCurrentNewCourseAcronym(enteredText.toUpperCase());
            setNewCourseAcronymError(false);
            let sem;
            if (currentNewCourseDate.getMonth() >= 2 && currentNewCourseDate.getMonth() < 10 ) sem = "SS";
            else sem = "WS";
            setCurrentNewCourseId(enteredText.toUpperCase() + sem + currentNewCourseDate.getFullYear().toString().substr(-2));
            // console.log('currentNewCourseId: ' + currentNewCourseId)
        }
    }
    const changeNewCourseMinMembersHandler = (number) => {
        setCurrentNewCourseMinMembers(number);
        if (number > currentNewCourseMaxMembers) setCurrentNewCourseMaxMembers(number);
    }
    const changeNewCourseMaxMembersHandler = (number) => {
        setCurrentNewCourseMaxMembers(number);
        if (number < currentNewCourseMinMembers) setCurrentNewCourseMinMembers(number);
    }
    const changeNewCourseDateHandler = (date) => {
        setCurrentNewCourseDate(date);
        let sem;
        if (date.getMonth() >= 2 && date.getMonth() < 10 ) sem = "SS";
        else sem = "WS";
        setCurrentNewCourseId(currentNewCourseAcronym + sem + date.getFullYear().toString().substr(-2));
        // console.log('currentNewCourseId: ' + currentNewCourseId)
        setNewCourseDateVisible(false);
    }

    const deleteCourseHandler = (id) => {
        
        // if (!deleteInfoReceived) {
        if (true) {
            setDeleteInfoVisible(true); 
        } else {
            //swipeListView.safeCloseOpenRow();
            DB.removeCourseFromList(id, () => {
                DB.getCourseList((courseList) => {
                    // console.log(courseList);
                    setCurrentCourses(courseList);
                    var joined = [];
                    for (const course in courseList) {
                        if (courseList[course].members.indexOf(currentUserId) >= 0) {
                            joined.push(courseList[course].id);
                        }
                    }
                    setJoinedCourses(joined);
                });
            });
        }
    }

    const selectCourseHandler = (id, title, date) => {
        //swipeListView.safeCloseOpenRow();
        const isMember = joinedCourses.indexOf(id) >= 0
        navigation.navigate("Course", { itemId: id, itemTitle: title, isMember: isMember, itemDate: date } );
    }

    const SectionList = ( props ) => {
        return (
            <FlatList
                data= { props.data }
                keyExtractor= { (item, index) => index.toString() }
                renderItem= { ( { item } ) => { 
                    return (
                        <Section 
                            semester= { item }
                        />
                    )
                }}
            />
        );
    }
    const Section = (props) => {
        return (
            <View>
                <View style= { boxes.separator } >
                    <Text style= { texts.separatorText } > { props.semester } </Text>
                </View>
                <FlatList
                    data= { currentCourses[props.semester] }
                    keyExtractor= { (item, index) => index.toString() }
                    renderItem= { ( { item, index } ) => { 
                        // console.log('currentCourses: ')
                        // console.log(currentCourses)
                        return (
                            <TouchableHighlight
                                underlayColor= { colors.darkBlue }
                                onPress= { () => { selectCourseHandler(item.id, item.title, item.date) } }
                            >
                                <View
                                    style= { {
                                        flexDirection: "row", 
                                        justifyContent: "space-between", 
                                        alignItems: "center",
                                        backgroundColor: index % 2 === 0 ? colors.white : colors.lightGrey,
                                    } }
                                >
                                    <ListTile
                                        onPress= { () => { selectCourseHandler(item.id, item.title, item.date) } } 
                                        id= { item.id }
                                        title= { item.title }
                                        subtitle= { 
                                            // item.members.length + 
                                            " Mitglieder, Gruppengröße " + item.minMembers + "-" + item.maxMembers + "\n" + item.date
                                        }
                                        index = { index }
                                        isMember = { joinedCourses.indexOf(item.id) >= 0 }
                                    />
                                    <View
                                        style= { {
                                            flexDirection: "row", 
                                            paddingHorizontal: 10,
                                        } }
                                    >
                                        <ButtonIcon 
                                            icon= { "nogo" }
                                            onPress= { (ref) => { deleteCourseHandler(item.id) } }
                                            status= { "neg" }
                                        />
                                    </View>
                                </View>
                            </TouchableHighlight>
                        )
                    } }
                />
            </View>
        )
    }

    return(
        <View 
            style= { { flex:1, width: '100%', height: '100%', } } 
            showsHorizontalScrollIndicator= { false } 
            showsVerticalScrollIndicator= { false }
        >

            {/* Info-Einblendung */}
            <InfoModal visible={deleteInfoVisible}
                onPress={() => {setDeleteInfoVisible(false); storeInfoReceived("deleteInfoReceived"); setDeleteInfoReceived(true);}}
                title="Kurs aus Liste löschen"
                copy="Durch diese Aktion wird der Kurs aus deiner Liste entfernt. Möchtest du einen Kurs in der Liste behalten, aber kein Mitglied sein, tritt stattdessen auf der Kurs-Seite aus. Natürlich kannst du einen entfernten Kurs jederzeit über den Finden-Button wieder hinzufügen."
            />

            {/* Kurs finden */}
            <Modal visible= { findCourseVisible } animationType= 'slide'>
                <ModalContent
                    subheader= { () => {}}
                    content= { () => {
                        return(
                            <View style={boxes.mainContainer}>
                                <Text style={texts.titleCentered}>{"Kurs finden"}</Text>
                                <InputField
                                    placeholderText= "Kurs-ID eingeben"
                                    value={currentFindCourseId}
                                    onChangeText={changeFindCourseIdHandler}
                                />
                            </View>
                        )
                    }}
                    onDismiss= {pressFindCourseHandler}
                />
            </Modal>

            {/* Kurs erstellen */}
            <Modal visible= { newCourseVisible } animationType= 'slide' style= { { width: width,height: height } } >
                {/* Datum wählen */}
                <DateModal
                    visible= { newCourseDateVisible }
                    onPress= { (date) => { changeNewCourseDateHandler(date) } }
                />
                
                <ModalContent
                    subheader= { () => {}}
                    content= { () => 
                        <View style={boxes.mainContainer}>
                            <Text style={texts.titleCentered}>{"Kurs erstellen"}</Text>
                            <InputField
                                title= "Kursname"
                                placeholderText= "Kursname"
                                // value={currentNewCourseName}
                                onChangeText={changeNewCourseNameHandler}
                            />
                            { newCourseNameError && 
                                <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                    Gebe einen Kursnamen ein.
                                </Text>
                            }
                            <InputField
                                title= "Kürzel"
                                placeholderText= "KürzelSemesterJahr"
                                // value={currentNewCourseAcronym}
                                onChangeText={changeNewCourseAcronymHandler}
                            />
                            { newCourseAcronymError && 
                                <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                    Gebe ein Kürzel für den Kurs ein.
                                </Text>
                            }
                            <InputField
                                title= "End-Datum"
                                isButton= { true }
                                icon= { icons.date }
                                placeholderText= "Datum auswählen …"
                                value= { format(currentNewCourseDate, "dd.MM.yyyy") }
                                onPress= { () => { setNewCourseDateVisible(true) } }
                            />
                            {/* { newCourseDateErrorVisible &&
                                <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                    Das Datum muss in der Zukunft liegen.
                                </Text> */
                            }
                            <View style={boxes.unPaddedRow}>
                                <NumberInput
                                    title= {"Mitglieder min."}
                                    value= {currentNewCourseMinMembers}
                                    onChange={changeNewCourseMinMembersHandler}
                                    />
                                <NumberInput
                                    title= {"Mitglieder max."}
                                    value= {currentNewCourseMaxMembers}
                                    onChange={changeNewCourseMaxMembersHandler}
                                />
                            </View>
                            <Text style={[boxes.unPaddedRow, texts.errorLine]}>
                                Eine Kurs-ID wird aus dem Kürzel und aus dem Semester und dem Jahr des End-Datums erzeugt.
                            </Text>
                        </View> 
                    }
                    onDismiss= { (commit) => { pressNewCourseHandler(commit) } }
                    // onDismiss= { () => { console.log('currentNewCourseId = ' + currentNewCourseId)}}
                />
            </Modal>

            {/* Find & Create Buttons */}
            <View style= { boxes.subHeader } >
                <View style= { boxes.paddedRow } >
                    <ButtonSmall
                        title= { "Kurs finden"}
                        icon= { "find" }
                        onPress= { () => {setFindCourseVisible(true) } }
                    />
                    <ButtonSmall
                        title= { "Neuer Kurs" }
                        icon= { "plus" }
                        onPress= { () => {setNewCourseVisible(true) } }
                    />
                </View>
            </View>

            {/* Course-List */}
            <SectionList 
                data = {Object.keys(currentCourses)}
            />

            {/* Logout-Button will be removed soon */}
            <View style= { boxes.mainContainer }>
                <ButtonLarge 
                    title= "Logout"
                    onPress= { () => DB.signOut( () => { console.log("Logout") } ) }
                />
            </View>
        </View>
    );
}