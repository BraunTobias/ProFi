import React from "react";
import { View, TouchableWithoutFeedback, Keyboard, StatusBar, ScrollView } from "react-native";
//import { ScrollView } from "react-native-gesture-handler";

import { boxes } from '../Styles';
import ButtonLarge from '../components/ButtonLarge';

export default function ModalComponent (props) {
    return (
        // <TouchableWithoutFeedback onPress= { () => Keyboard.dismiss() }>
            <View style={{flex: 1}}>
                <StatusBar barStyle="dark-content"/>

                <View style={ boxes.modal }>

                    { props.subheader() }

                    <ScrollView 
                        bounces={false}
                        contentContainerStyle={boxes.modalScrollView}
                    >
                        { props.content() }
                    </ScrollView>

                    <View style={boxes.modalButton}>
                        <ButtonLarge
                            title={"Bestätigen"}
                            onPress={ () => {props.onDismiss(true)} }
                        />
                        <ButtonLarge
                            title={"Abbrechen"}
                            transparent={true}
                            onPress={() => {props.onDismiss(false)} }
                        />
                    </View>
                </View>
            </View>
        // </TouchableWithoutFeedback>
    );
};