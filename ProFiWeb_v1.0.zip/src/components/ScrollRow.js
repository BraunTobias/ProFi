import React from "react";
import { View, FlatList, ScrollView } from "react-native";

import { boxes } from '../Styles';
import AttributeImage from "./AttributeImage";
import ProfileImage from "./ProfileImage";

export default function ScrollRow (props) {

    const data = props.data;

    return(
        <View style= { boxes.scrollRow }>
            <ScrollView
                horizontal= { true }
                // indicatorStyle
                // showsHorizontalScrollIndicator= { false }
            >
                <FlatList 
                    style= { { paddingLeft: 15 } }
                    horizontal= { true }
                    showsHorizontalScrollIndicator= { false }
                    showsVerticalScrollIndicator= { false }
                    data= { data }
                    keyExtractor= { (item, index) => index.toString() }
                    renderItem= { (itemData) => { 
                        if (props.type === "attributes") {
                            return (
                                <AttributeImage
                                    imageUrl= { itemData.item.imageUrl }
                                    isLast= { itemData.index == data.length - 1 }
                                    title= { itemData.item }
                                    isActive= { props.currentCategory === itemData.item }
                                    onPress= { () => { props.onPress(itemData.item) } }
                                />
                            );
                        } else {
                            return (
                                <ProfileImage
                                    imageUrl= { itemData.item.imageUrl }
                                    isLast= { itemData.index === data.length - 1 }
                                    onPress= { () => { props.onPress(itemData.item.userId) } }
                                />
                            );
                        }
                    }}
                />
            </ScrollView>
        </View>
    );
};